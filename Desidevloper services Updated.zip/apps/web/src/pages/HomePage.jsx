
import React from 'react';
import { Helmet } from 'react-helmet';
import HeroSection from '@/components/HeroSection';
import ServicesSection from '@/components/ServicesSection';
import BottomBubble from '@/components/BottomBubble';

function HomePage() {
  return (
    <>
      <Helmet>
        <title>Oxygen Services | Prompt 2 Production</title>
        <meta name="description" content="Oxygen Services - Transforming ideas into digital reality. Works for Services, Gigs, and Future SaaS. Prompt 2 Production." />
      </Helmet>

      <main className="min-h-screen bg-purple-950 text-white selection:bg-yellow-400 selection:text-purple-900">
        <HeroSection />
        <ServicesSection />
        <BottomBubble />
      </main>
    </>
  );
}

export default HomePage;
