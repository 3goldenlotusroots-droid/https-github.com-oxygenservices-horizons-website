import React from 'react';
import WaterBubble from './WaterBubble';
import { MessageCircle, Linkedin, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
const BottomBubble = () => {
  return <section className="relative py-20 px-6 bg-purple-950 flex justify-center overflow-hidden">
      {/* Ambient Glow */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-blue-500/20 blur-[100px] rounded-full pointer-events-none" />

      <WaterBubble circular={true} className="max-w-[600px] w-full" delay={1}>
        <div className="flex flex-col items-center justify-center h-full space-y-8 w-full max-w-md">
          <h2 className="text-3xl md:text-5xl font-bold text-white text-center leading-tight">
            Ready to <br />
            <span className="text-yellow-400 italic">Flow?</span>
          </h2>
          
          <p className="text-blue-100 text-lg text-center leading-relaxed">Connect with us to turn your prompts into production-ready reality .

प्रॉब्लम है? शेयर करो। सॉल्यूशन रेडी है</p>

          <div className="flex flex-col gap-4 w-full max-w-xs">
            <a href="https://wa.me/919727413309" target="_blank" rel="noopener noreferrer" className="w-full">
              <Button className="w-full bg-green-500 hover:bg-green-600 text-white font-bold text-lg py-6 rounded-full shadow-lg hover:shadow-green-500/30 transition-all transform hover:scale-105">
                <MessageCircle className="w-6 h-6 mr-2" />
                WhatsApp Us
              </Button>
            </a>

            <a href="https://linkedin.com/in/milan-soni-54953328" target="_blank" rel="noopener noreferrer" className="w-full">
              <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold text-lg py-6 rounded-full shadow-lg hover:shadow-blue-600/30 transition-all transform hover:scale-105">
                <Linkedin className="w-6 h-6 mr-2" />
                Connect on LinkedIn
              </Button>
            </a>
          </div>

          <div className="pt-4 border-t border-white/10 w-full text-center">
            <p className="text-sm text-blue-200/60">
              Oxygen Services • <a href="https://desidevelopers.com" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors inline-flex items-center">desidevelopers.com <ExternalLink className="w-3 h-3 ml-1" /></a>
            </p>
          </div>
        </div>
      </WaterBubble>
    </section>;
};
export default BottomBubble;