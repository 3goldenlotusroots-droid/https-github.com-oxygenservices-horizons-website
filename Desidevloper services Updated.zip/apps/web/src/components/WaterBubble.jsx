
import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const WaterBubble = ({ children, className, delay = 0, circular = false }) => {
  return (
    <motion.div
      initial={{ y: 0, scale: 0.95, opacity: 0 }}
      animate={{ 
        y: [0, -15, 0],
        scale: [0.98, 1.02, 0.98],
        opacity: 1
      }}
      transition={{ 
        y: {
          duration: 4,
          repeat: Infinity,
          ease: "easeInOut",
          delay: delay
        },
        scale: {
          duration: 5,
          repeat: Infinity,
          ease: "easeInOut",
          delay: delay
        },
        opacity: { duration: 0.8 }
      }}
      className={cn(
        "relative overflow-hidden backdrop-blur-xl bg-white/10 border border-white/20 shadow-[0_8px_32px_0_rgba(31,38,135,0.37)]",
        "flex flex-col items-center justify-center text-center",
        "before:content-[''] before:absolute before:top-0 before:left-0 before:right-0 before:bottom-0 before:bg-gradient-to-br before:from-white/20 before:to-transparent before:pointer-events-none",
        circular ? "rounded-full aspect-square p-8 md:p-16" : "rounded-[3rem] p-8 md:p-12",
        className
      )}
    >
      {/* Glossy reflection effect */}
      <div className={cn(
        "absolute bg-white/20 rounded-full blur-xl transform -rotate-12 pointer-events-none",
        circular ? "top-[15%] left-[20%] w-[25%] h-[12%]" : "top-4 left-8 w-24 h-12"
      )} />
      
      <div className="relative z-10 w-full flex flex-col items-center justify-center h-full">
        {children}
      </div>
    </motion.div>
  );
};

export default WaterBubble;
