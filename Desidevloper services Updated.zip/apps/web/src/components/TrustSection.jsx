
import React from 'react';
import { Phone, Globe, Award } from 'lucide-react';

function TrustSection() {
  return (
    <section id="contact" className="py-16 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="bg-gradient-to-br from-purple-50 via-white to-blue-50 rounded-3xl shadow-xl p-12 border border-purple-200">
          {/* Business Name */}
          <div className="text-center mb-8">
            <h2 className="text-4xl md:text-5xl font-black bg-gradient-to-r from-purple-600 via-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
              Oxygen Services
            </h2>
            <div className="flex items-center justify-center gap-2 text-yellow-600 mb-6">
              <Award className="w-6 h-6" />
              <p className="text-xl font-semibold">
                Trusted by Site Managers & Founders
              </p>
            </div>
          </div>

          {/* Contact Information */}
          <div className="space-y-6">
            {/* Phone */}
            <div className="flex items-center justify-center gap-4 bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center shadow-lg">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-sm text-gray-600 font-medium">Contact Phone</p>
                <a 
                  href="tel:9727413309"
                  className="text-2xl font-bold text-gray-900 hover:text-purple-600 transition-colors"
                >
                  9727413309
                </a>
              </div>
            </div>

            {/* Website */}
            <div className="flex items-center justify-center gap-4 bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center shadow-lg">
                <Globe className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-sm text-gray-600 font-medium">Website</p>
                <a 
                  href="https://desidevelopers.com" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-2xl font-bold text-gray-900 hover:text-blue-600 transition-colors"
                >
                  desidevelopers.com
                </a>
              </div>
            </div>
          </div>

          {/* Decorative Elements */}
          <div className="mt-8 flex justify-center gap-3">
            <div className="w-3 h-3 bg-purple-500 rounded-full animate-bounce" />
            <div className="w-3 h-3 bg-blue-500 rounded-full animate-bounce delay-100" />
            <div className="w-3 h-3 bg-yellow-500 rounded-full animate-bounce delay-200" />
          </div>
        </div>
      </div>
    </section>
  );
}

export default TrustSection;
