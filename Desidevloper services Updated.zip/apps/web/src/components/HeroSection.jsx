import React from 'react';
import WaterBubble from './WaterBubble';
import { Sparkles } from 'lucide-react';

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden py-20">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat bg-fixed"
        style={{
          backgroundImage: 'url(https://horizons-cdn.hostinger.com/81ec90ad-2885-4fcf-b8ad-e2fca8ce0532/cdbf1ffda95323989f72169c42b7b3cd.png)',
        }}
      />
      
      {/* Gradient Overlay - Ocean Blue Palette */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0066CC]/90 to-[#003D82]/90 mix-blend-multiply" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/30" />

      {/* Content Container */}
      <div className="relative z-10 container mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        
        {/* Left Side: Circular Water Bubble */}
        <div className="flex justify-center lg:justify-start">
          <WaterBubble 
            circular={true}
            className="max-w-[500px] w-full mx-auto lg:mx-0"
          >
            <div className="space-y-6 flex flex-col items-center justify-center h-full">
              <div className="inline-flex p-3 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 mb-2">
                <Sparkles className="w-8 h-8 text-yellow-400 animate-pulse" />
              </div>
              
              <h1 className="text-4xl md:text-6xl font-black text-white tracking-tight drop-shadow-lg text-center leading-tight">
                Oxygen
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-300 via-blue-100 to-blue-300">
                  Services
                </span>
              </h1>
              
              <div className="w-24 h-1.5 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full shadow-[0_0_15px_rgba(250,204,21,0.6)]" />
              
              <h2 className="text-2xl md:text-4xl font-serif italic font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-yellow-200 to-yellow-400 drop-shadow-md text-center leading-tight">
                Prompt 2 Production
              </h2>
            </div>
          </WaterBubble>
        </div>

        {/* Right Side: Slogan */}
        <div className="text-center lg:text-left space-y-8">
          <h2 className="text-6xl md:text-8xl font-serif italic font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-yellow-200 to-yellow-400 drop-shadow-[0_0_25px_rgba(234,179,8,0.5)] animate-pulse">
            Prompt 2 Production
          </h2>
          
          {/* Tagline removed as requested */}
        </div>
      </div>

      {/* Decorative Glows - Updated to match Ocean Blue theme */}
      <div className="absolute top-1/4 right-0 w-96 h-96 bg-blue-400/30 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-full h-64 bg-cyan-500/20 rounded-full blur-[120px] pointer-events-none" />
    </section>
  );
};

export default HeroSection;