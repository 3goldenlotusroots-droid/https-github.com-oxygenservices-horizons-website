
import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

const ServiceCard = ({ title, description, icon: Icon, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1 }}
      whileHover={{ scale: 1.05, y: -5 }}
      className="group relative bg-gradient-to-br from-purple-900/40 to-blue-900/40 backdrop-blur-md border border-white/10 rounded-2xl p-6 md:p-8 shadow-lg hover:shadow-2xl hover:shadow-purple-500/20 transition-all duration-300"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-blue-500/10 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      
      <div className="relative z-10">
        <div className="w-14 h-14 mb-6 rounded-xl bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
          <Icon className="w-7 h-7 text-white" />
        </div>
        
        <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-yellow-400 transition-colors">
          {title}
        </h3>
        
        <p className="text-gray-300 leading-relaxed mb-6">
          {description}
        </p>
        
        <div className="flex items-center text-sm font-semibold text-blue-300 group-hover:text-white transition-colors">
          <span>Learn more</span>
          <ArrowRight className="w-4 h-4 ml-2 transform group-hover:translate-x-1 transition-transform" />
        </div>
      </div>
    </motion.div>
  );
};

export default ServiceCard;
