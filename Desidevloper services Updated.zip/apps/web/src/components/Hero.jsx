
import React from 'react';
import { MessageCircle, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useGetDailyOneLiner } from '@/components/DailyOneLiners';

function Hero() {
  const dailyOneLiner = useGetDailyOneLiner();

  return (
    <section 
      id="home" 
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: 'url(https://images.unsplash.com/photo-1585892125308-f7f0597764ff)',
        }}
      />

      {/* Vibrant Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900/95 via-purple-800/90 to-blue-900/95" />

      {/* Animated Glow Effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500/30 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/30 rounded-full blur-3xl animate-pulse delay-1000" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-5xl mx-auto">
        {/* Sparkle Icon */}
        <div className="flex justify-center mb-6">
          <Sparkles className="w-16 h-16 text-yellow-400 animate-pulse" />
        </div>

        {/* Main Headline */}
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-black text-white mb-6 leading-tight">
          <span className="inline-block drop-shadow-[0_0_30px_rgba(168,85,247,0.9)]">
            Oxygen
          </span>
          <br />
          <span className="inline-block bg-gradient-to-r from-yellow-400 via-yellow-300 to-yellow-400 bg-clip-text text-transparent drop-shadow-[0_0_40px_rgba(251,191,36,0.8)]">
            Services
          </span>
        </h1>

        {/* Daily One-Liner */}
        <p className="text-xl md:text-3xl italic text-yellow-300 mb-8 font-light drop-shadow-[0_0_20px_rgba(251,191,36,0.6)]">
          "{dailyOneLiner}"
        </p>

        {/* Subheading */}
        <p className="text-lg md:text-2xl text-purple-100 mb-12 font-medium max-w-3xl mx-auto leading-relaxed">
          Transforming Ideas Into Digital Reality
        </p>

        {/* CTA Button */}
        <a 
          href="https://wa.me/919727413309" 
          target="_blank" 
          rel="noopener noreferrer"
        >
          <Button className="bg-gradient-to-r from-green-500 via-green-600 to-green-500 hover:from-green-600 hover:via-green-700 hover:to-green-600 text-white font-bold text-lg px-10 py-7 rounded-full shadow-[0_0_40px_rgba(34,197,94,0.6)] hover:shadow-[0_0_60px_rgba(34,197,94,0.8)] transition-all duration-300 transform hover:scale-105">
            <MessageCircle className="w-6 h-6 mr-3" />
            Contact Us on WhatsApp
          </Button>
        </a>

        {/* Decorative Elements */}
        <div className="mt-16 flex justify-center gap-4">
          <div className="w-2 h-2 bg-yellow-400 rounded-full animate-ping" />
          <div className="w-2 h-2 bg-purple-400 rounded-full animate-ping delay-200" />
          <div className="w-2 h-2 bg-blue-400 rounded-full animate-ping delay-500" />
        </div>
      </div>
    </section>
  );
}

export default Hero;
